package com.example.ortoolsapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrtoolsApplicationTests {

    @Test
    void contextLoads() {
    }

}
