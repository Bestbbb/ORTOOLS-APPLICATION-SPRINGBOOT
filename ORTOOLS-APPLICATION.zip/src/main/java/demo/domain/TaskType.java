package demo.domain;

public enum TaskType {
    SOURCE,
    STANDARD,
    SINK;
}
