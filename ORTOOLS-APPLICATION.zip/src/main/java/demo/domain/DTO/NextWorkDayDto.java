package demo.domain.DTO;

import lombok.Data;

@Data
public class NextWorkDayDto {
    private String date;

    private long rest;

}
