package demo.domain;



import java.util.List;

public class Schedule{

    private List<ManufacturerOrder> manufacturerOrderList;

    private List<Task> taskList;
    private List<ResourceItem> resourceList;
//    private List<ResourceRequirement> resourceRequirementList;

    private List<Allocation> allocationList;



}
