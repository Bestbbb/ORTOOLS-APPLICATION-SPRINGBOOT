package demo.domain;

import lombok.Data;

@Data
public class SubPhaseThreeTask extends PhaseThreeAssignedTask{
    private Integer subStart;
    private Integer subEnd;
//    private Integer subQuantity;
}
