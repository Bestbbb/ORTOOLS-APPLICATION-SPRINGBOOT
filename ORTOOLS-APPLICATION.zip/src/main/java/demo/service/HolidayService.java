package demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import demo.domain.Holiday;


public interface HolidayService extends IService<Holiday> {

}
