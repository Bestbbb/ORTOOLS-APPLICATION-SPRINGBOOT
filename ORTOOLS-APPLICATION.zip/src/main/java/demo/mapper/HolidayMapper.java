package demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import demo.domain.Holiday;

/**
 * @author Ruiyu
 */
public interface HolidayMapper extends BaseMapper<Holiday> {
}
